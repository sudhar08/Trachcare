// ignore_for_file: unused_import

import 'package:flutter/material.dart';
import 'package:trachcare/components/Loginform.dart';

const whiteColor = Colors.white;
const loginFormcolor = Color(0XFFFFD9A0);
const BlackColor_light = Color.fromARGB(115, 0, 0, 0);
const admin_color = Color.fromARGB(255, 71, 215, 92);
const TitleColor = Color(0XFFA7DBAF);
const Logoutbtncolor = Color(0XFFB8DABD);
const BlackColor = Colors.black;
const grey_color = Color.fromARGB(179, 20, 20, 20);
const sucess_color = Colors.green;
const main_color= Color(0xFFA7DBAF);
const maincolor = LinearGradient(colors: [Color(0xFFA7DBAF), Color(0xFFFFD9A0)],);