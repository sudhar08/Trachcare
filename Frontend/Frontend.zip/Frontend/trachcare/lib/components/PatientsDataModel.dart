class Patientsdatamodel{
  final String patientslist;

  Patientsdatamodel(this.patientslist);
}