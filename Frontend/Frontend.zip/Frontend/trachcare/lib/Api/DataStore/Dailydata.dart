class Dailydata{
  Map <String,String> DailydataStore = <String,String>{};
  
}