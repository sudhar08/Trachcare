package com.simats.trachcare

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
