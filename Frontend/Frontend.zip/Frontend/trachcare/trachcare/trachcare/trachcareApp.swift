//
//  trachcareApp.swift
//  trachcare
//
//  Created by SAIL L1 on 12/12/24.
//

import SwiftUI

@main
struct trachcareApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
